public interface equals {
    boolean equals(String login);
}
