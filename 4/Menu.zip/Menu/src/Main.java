import java.math.MathContext;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        final int  currentYear = 2023;
        final double exchangeRatesUsdToEuro = 0.91;
        System.out.print("Здраствуйте, пожалуйста напишите ваше Имя:");
        String name = scanner.nextLine();
        System.out.println("Привет, " + name);


        System.out.print(name +", укажите пожалуйста год вашего рождения");
        int yearOfBirth = scanner.nextInt();
        System.out.print("Введите название города в которым вы в данный момент проживаете: ");
        String userCity = scanner.nextLine();
        System.out.print("Ваш любимый цвет: ");
        String favoriteColor = scanner.nextLine();
        System.out.print("Имя вашего кота: ");
        String nameUserCat = scanner.nextLine();
        System.out.println(name + " Вам сейчас: " + (currentYear - yearOfBirth) + " лет, " + " проживаете в городе: " + userCity +
                " любимый цвет: " + favoriteColor + ". И вашего пушистого друга зовут: " + nameUserCat);





        System.out.print("Введите длину стороны квадрата:");
        double length = scanner.nextDouble();
        double perimeter = length*4;
        System.out.println("Периметр квадрата: " + perimeter);


        System.out.print("Введите радиус окружности: ");
        double radius = scanner.nextDouble();
        double square = Math.PI * ( radius * radius);
        System.out.println("Площадь окружности: " + square);

        System.out.print("Введите расстояние между двумя городами");
        double distance = scanner.nextDouble();
        System.out.print("За какое время вы хотите добраться?");
        double time = scanner.nextDouble();
        double speed = distance/time;
        System.out.println("Вам необходимо двигаться со скоростью " + speed);

        System.out.print("Введите сумму Долларов которую вы хотите конвертировать в Евро: ");
        double dollars = scanner.nextDouble();
        double euro = dollars*exchangeRatesUsdToEuro;
        System.out.println(dollars + " Долларов, будет равняться: " + euro + "Евро");

        System.out.println("Введите обьём флеш-карты в Гб: ");
        int flashCard = scanner.nextInt();
        int file = 820;
        int amount = flashCard*1000/file;
        System.out.println("На вашей флеш-карте поместится " + amount + " файлов размеров в 820 Мб");




    }
}